
  export const contractAddress = "0xb2d9d11Ce6780B9ac9bc3E0B222b5596ABd9E49c"
  export const ownerAddress = "0x288b70c954FF4A0DBb374Cb3b4e4FE406Abe0159"
  